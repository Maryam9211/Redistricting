package org.nocrala.tools.gis.data.esri.shapefile.exception;

public class DataStreamEOFException extends Exception {

  private static final long serialVersionUID = 8466326330420094052L;

  public DataStreamEOFException() {
    super();
  }

}
