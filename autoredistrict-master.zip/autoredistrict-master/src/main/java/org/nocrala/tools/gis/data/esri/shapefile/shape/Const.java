package org.nocrala.tools.gis.data.esri.shapefile.shape;

import org.nocrala.tools.gis.data.esri.shapefile.NocralaShapeFileReader;

public class Const {

  public static final String PREFERENCES = "You can change the validation preferences using "
      + "the additional constructor of the "
      + NocralaShapeFileReader.class.getName()
      + " class.";
}
