package util.GenericClasses;


public class Quadruplet<T1, T2, T3, T4> {
	public T1 a;
	public T2 b;
	public T3 c;
	public T4 d;
	public Quadruplet(T1 _a, T2 _b, T3 _c, T4 _d) {
		a = _a;
		b = _b;
		c = _c;
		d = _d;
	}
}
