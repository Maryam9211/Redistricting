package solutions;

public interface iDiscreteEventListener {
	void eventOccured();
}
