package solutions;

public interface iChangeListener {
	void valueChanged();
}
