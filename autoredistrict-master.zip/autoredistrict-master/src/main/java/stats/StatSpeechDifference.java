package stats;

public class StatSpeechDifference {

}
