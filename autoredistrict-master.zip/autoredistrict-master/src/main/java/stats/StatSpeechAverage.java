package stats;

public class StatSpeechAverage {

}
